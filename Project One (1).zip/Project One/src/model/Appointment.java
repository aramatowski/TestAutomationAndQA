package model;

import java.util.*;
import java.util.Date;

public class Appointment {

	private String appointmentId;
	private Date date;
	private String description;
	
	public Appointment(String appointmentId, Date date, String description) {
		
		
		
		//validate inputs against requirements
		boolean isValid = validateInput(appointmentId, 10);
		
		if (isValid) {
			this.appointmentId = appointmentId;
		}
		
		isValid = isValid && setAppointmentDate(date);
		isValid = isValid && setAppointmentDescription(description);
		
		if (!isValid) {
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	public boolean setAppointmentDate(Date date) {
		
		boolean isValid = validateInput(date, !date.before(new Date()));
		
		if (isValid) {
			this.date = date;
		}
		return isValid;
	}
	
	public boolean setAppointmentDescription(String description) {
		boolean isValid = validateInput(description, 50);
		
		if (isValid) {
			this.description = description;
		}
		return isValid;
	}
	
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public Date getAppointmentDate() {
		return date;
	}
	
	public String getAppointmentDescription() {
		return description;
	}
}
