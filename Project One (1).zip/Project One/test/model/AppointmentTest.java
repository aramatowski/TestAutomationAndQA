package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Calendar;

import model.Appointment;

class AppointmentTest {

	@Test
	void testCreateAppointmentSuccess() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(2022, 01, 01);
		Appointment appointment = new Appointment("123456", calendar.getTime(), "Appointment Description.....");
		
		assertTrue(appointment != null);
		assertTrue(appointment.getAppointmentId().equals("123456"));
		assertTrue(appointment.getAppointmentDate().equals(calendar.getTime()));
		assertTrue(appointment.getAppointmentDescription().equals("Appointment Description....."));
	}
	
	@Test
	void testCreateAppointmentAppointmentIdFails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Calendar calendar = Calendar.getInstance();
			calendar.set(2022, 01, 01);
			new Appointment("123456789000", calendar.getTime(), "Appointment Description.....");
		});
	}
	
	@Test
	void testCreateAppointmentAppointmentDateFails() {
		Assertions.assertThrows(IllegalArgumentException.class () -> {
			Calendar calendar = Calendar.getInstance();
			calendar.set(2020, 01, 01);
			new Appointment("123456", calendar.getTime(), "Appointment Description.....");
		});
	}
	
	@Test
	void testCreateAppointmentAppointmentDescriptionFails() {
		Assertions.assertThrows(IllegalArgumentException.class () -> {
			Calendar calendar = Calendar.getInstance();
			calendar.set(2022, 01, 01);
			new Appointment("123456", calendar.getTime(), "Appointment Description.........................");
		});
	}
}
