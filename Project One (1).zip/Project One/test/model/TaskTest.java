package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import model.Task;

class TaskTest {

	@Test
	void testCreateTaskSuccess() {
		Task task = new Task("123456", "Task1", "Task1 Description.....");
		
		assertTrue(task != null);
		assertTrue(task.getTaskId().equals("123456"));
		assertTrue(task.getName().equals("Task1"));
		assertTrue(task.getDescription().equals("Task1 Description....."));
	}
	
	@Test
	void testCreateTaskTaskIdFaails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678900", "Task1", "Task1 Description.....");
		});
	}
	
	@Test
	void testCreateTaskTaskNameFails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456", "Task1Nameeeeeeeeeeeee", "Task1 Description.....");
		});
	}
	
	@Test
	void testCreateTaskTaskDescriptionFails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456", "Task1", "Task1 Descriptionnnnnnnnnnnnnnnnnnnnnnnnnnnnnn.....");
		});
	}
}
