package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import model.Contact;

class ContactTest {

	//Test Contact create
	@Test
	void testCreateContactSuccess() {
		Contact contact = new Contact("123456", "John", "Doe", "1111 Street Road", "1234567890");
		
		assertTrue(contact != null);
		assertTrue(contact.getContactId().equals("123456"));
		assertTrue(contact.getFirstName().equals("John"));
		assertTrue(contact.getLastName().equals("Doe"));
		assertTrue(contact.getAddress().equals("1111 Street Road"));
		assertTrue(contact.getPhoneNumber().equals("1234567890"));
	}
	
	@Test
	void testCreateContactContactIdFails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "John", "Doe", "1111 Street Road", "1234567890");
		});
	}
	
	@Test
	void testCreateContactFirstNameFails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "Johnnnnnnnn", "Doe", "1111 Street Road", "1234567890");
		});
	}
	
	@Test
	void testCreateContactLastNameFails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "John", "Doeeeeeeeee", "1111 Street Road", "1234567890");
		});
	}
	
	@Test 
	void testCreateContactAddressFails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "John", "Doe", "1111 Street Roaddddddddddddddd", "1234567890");
		});
	}
	
	@Test
	void testCreateContactNumberTooLongFails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "John", "Doe", "1111 Street Road", "12345678900");
		});
	}
	
	@Test
	void testCreateContactNumberTooShortFails() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456", "John", "Doe", "1111 Street Road", "1234567");
		});
	}
	
	//Test Contact Update
	
	@Test 
	void testUpdateContactSuccess() {
		Contact contact = new Contact("123456", "John", "Doe", "1111 Street Road", "1234567890");
		
		contact.setAddress("New Address");
		contact.setContactFirstName("Jarrod");
		contact.setContactLastName("Smith");
		contact.setPhoneNumber("1112223333");
		
		assertTrue(contact.getContactId().equals("123456"));
		assertTrue(contact.getFirstName().equals("Jarrod"));
		assertTrue(contact.getLastName().equals("Smith"));
		assertTrue(contact.getAddress().equals("New Address"));
		assertTrue(contact.getPhoneNumber().equals("1112223333"));
	}
	
	@Test
	void testUpdateContactAddressFails() {
		Contact contact = new Contact("123456", "John", "Doe", "1111 Street Road", "1234567890");
		assertFalse(contact.setAddress("1111 Street Roadddddddddddd"));
	}
	
	@Test
	void testUpdateContactFirstNameFails() {
		Contact contact = new Contact("123456", "John", "Doe", "1111 Street Road", "1234567890");
		assertFalse(contact.setContactFirstName("Johnnnnnnnnnn"));
	}
	
	@Test
	void testUpdateContactLastNameFails() {
		Contact contact = new Contact("123456", "John", "Doe", "1111 Street Road", "1234567890");
		assertFalse(contact.setContactLastName("Doeeeeeeeeee"));
	}
	
	@Test
	void testUpdateContactNumberNotDigitFails() {
		Contact contact = new Contact("123456", "John", "Doe", "1111 Street Road", "1234567890");
		assertFalse(contact.setPhoneNumber("ABCDE12345"));
	}
	
	@Test
	void testUpdateContactNumberTooShortFaails() {
		Contact contact = new Contact("123456", "John", "Doe", "1111 Street Road", "1234567890");
		assertFalse(contact.setPhoneNumber("123456"));
	}
	
	@Test
	void testUpdateContactNumberTooLongFails() {
		Contact contact = new Contact("123456", "John", "Doe", "1111 Street Road", "1234567890");
		assertFalse(contact.setPhoneNumber("1234567890000"));
	}
}
