package service;

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assettions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.Calendar;

import model.Appointment;
import model.AppointmentService;

class AppointmentServiceTest {

	private static final service.AppointmentService appointmentService = null;

	private static AppointmentService = appointmentService;
	
	@BeforeAll
	static void setup() {
		appointmentService = AppointmentService.getService();
	}
	
	@Test
	void testAddAppointmentSuccess() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(2022, 01, 01);
		Appointment appointment = new Appointment("123456", calendar.getTime(), "Appointment Description.....");
		assertTrue(appointmentService.addAppointment(appointment));
		
		Appointment cachedAppointment = appointmentService.getAppointment(appointment.getAppointmentId());
		
		assertTrue(cachedAppointment != null);
		assertTrue(cachedAppointment.getAppointmentId().equals("123456"));
		assertTrue(cachedAppointment.getAppointmentDate().equals(calendar.getTime()));
		assertTrue(cachedAppointment.getAppointmentDescription().equals("Appointment Description....."));
	}
	
	@Test
	void testAddMultipleAppointmentsSuccess() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(2022, 01, 01);
		Appointment appointment1 = new Appointment("123456", calendar.getTime(), "Appointment1 Description.....");
		Appointment appointment2 = new Appointment("123457", calendar.getTime(), "Appointment2 Description.....");
		
		assertTrue(appointmentService.addAppointment(appointment1));
		appointment1 = appointmentService.getAppointment(appointment1.getAppointmentId());
		
		assertTrue(appointment1 != null);
		assertTrue(appointment1.getAppointmentId().equals("123456"));
		assertTrue(appointment1.getApplicationDate().equals(calendar.getTime()));
		assertTrue(appointment1.getAppointmentDescription().equals("Appointment1 Description....."));
		
		assertTrue(appointmentService.addAppointment(appointment2));
		appointment2 = appointmentService.getAppointment(appointment2.getAppointmentId());
		
		assertTrue(appointment2 != null);
		assertTrue(appointment2.getAppointmentId().equals("123457"));
		assertTrue(appointment2.getAppointmentDate().equals(calendar.getTime()));
		assertTrue(appointment2.getDescription().equals("Appointment2 Description....."));
	}
	
	@Test
	void testAddTaskDuplicateIdFails() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(2022, 01, 01);
		Appointment appointment1 = new Appointment("123456", calendar.getTime(), "Appointment1 Description.....");
		Appointment appointment2 = new Appointment("123456", calendar.getTime(), "Appointment2 Description.....");
		
		assertTrue(appointmentService.addAppointment(appointment1));
		assertFalse(appointmentService.addAppointment(appointment2));
	}
	
	@Test
	void getAppointmentAndDeleteSuccess() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(2022, 01, 01);
		Appointment appointment = new Appointment("123456", calendar.getTime(), "Appointment Description.....");
		
		assertTrue(appointmentService.addAppointment(appointment));
		
		appointment = appointmentService.getAppointment(appointment.getAppointmentId());
		assertTrue(task != null);
		
		assertTrue(appointmentService.deleteAppointment(appointment.getAppointmentId()));
		assertTrue(appointmentService.getAppointment(appointment.getAppointmentId()) == null);
	}
	
	@Test
	void testDeleteInvalidAppointmentFail() {
		String invalidAppointmentId = "123";
		
		assertFalse(appointmentService.deleteAppointment(invalidAppointmentId));
	}
}
